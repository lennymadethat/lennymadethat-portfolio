# RIR Data API Kit

A **paid programmatic data API** (Model B) for a curated income-ETF dataset — yields,
price, AUM, distributions, payout cadence, strategy and underlying classification.
Humans browse the dataset free on the website; **machines pay**. One Cloudflare Worker
serves both a REST API and an **MCP server** (for AI agents), gated by per-key tiers
behind a `402 payment_required` wall, with Stripe subscription billing and a Supabase
key store.

Built for The Retail Investor Report; ships as a **reusable kit** with a sanitization
boundary so it drops onto anyone's stack (their own Cloudflare + Supabase + Stripe + a
published dataset CSV).

---

## The loop

```
  agent / app          the Worker (REST + MCP)          tier gate              your dataset
 (needs data)  ──►   /api/v1/* or /mcp tool call  ──►  resolve key →     ──►   published CSV
                                                        free|pro|402            (cached 1h)
                          │                                  │
                          │  no key → 402 "get a key"        │ capped by tier
                          ▼                                  ▼  (no bulk export)
                  POST /api/keys (free)              JSON rows + rate-limit headers
                  Stripe Checkout → webhook → flips key to Pro
```

A human reads the site for free. A program hits the API, gets walled with `402` until it
holds a key, signs up free, and upgrades to Pro via Stripe when it needs all fields and
higher limits. **Every query is capped by tier — there is no bulk-dump endpoint;** the
full dataset is a separate commercial license.

---

## What's in the box

```
rir-api-kit/
├─ README.md                ← you are here
├─ EXPLAINER.md             ← plain-English "how it works" manual (the instruction manual)
├─ CONNECT.md               ← one-time setup: deploy the worker, set secrets, wire Stripe + Supabase
├─ manifest.json            ← agent-readable surface (an agent parses this to understand/run/buy it)
├─ config.example.json      ← swap these values for your stack (the sanitization boundary)
└─ worker/
   └─ README.md             ← the single-file Worker: source map, the architecture, how to deploy
```

---

## Quickstart

1. **Deploy the worker** — one `worker.js`, `npx wrangler deploy`. See `CONNECT.md`.
2. **Point it at your dataset** — set `MASTER_CSV` (a published-to-web spreadsheet or any CSV URL) and `SITE`.
3. **Set the secrets** — Supabase URL + service key, Stripe secret + webhook secret. `CONNECT.md` lists each.
4. **Create the `api_keys` table** — one Supabase table holds keys, tiers, and Stripe ids (SQL in `CONNECT.md`).
5. **Wire Stripe** — create a $X/mo recurring price, set `STRIPE_PRICE_ID`, register the webhook. The pay→Pro loop is automatic.
6. **(Optional, zero-config) demo keys** — the `API_KEYS` var carries `{"free_demo":"free","pro_demo":"pro"}` so the tiers are testable before Supabase + Stripe are live.

---

## Reuse it for your own stack (sanitization boundary)

Everything specific lives in **two places** — swap them and the kit is yours:

1. `config.example.json` → `config.json`: your dataset CSV URL, your public site URL, the
   tier shape (limits + which fields each tier sees), the field list, the Stripe price id.
   **No secrets in this file** — every credential is a Worker secret.
2. The **two constants at the top of `worker.js`**: `MASTER_CSV` (your dataset) and `SITE`
   (your public "get a key" page). Everything else reads from env + vars.

The worker code is already generic — tiers, fields, and the dataset are all data, not
hardcoded to one brand.

---

## Design tokens (for any HTML surface)

Kit HTML pages (docs, the `/api` product page) use the locked house tokens so everything
looks uniform: background `#0a1320`, gold `#f5b842`, mint `#6ee7c7`, surface `#0d1a2b` /
card `#11233a`, body text `#b9c6d6`; fonts Cinzel (display), Inter (body), JetBrains Mono
(data). Section headers = mint bold; primary buttons = gold background, `#0a1320` text.
Reuse these — do not invent new palettes per page.

---

## Status

- ✅ Worker LIVE: REST (`/api/v1/fund/:ticker`, `/api/v1/funds`) + MCP (`/mcp`: `about`, `get_free_key`, `upgrade_to_pro`, `get_fund`, `search_funds`), `402` agent wall, per-key day/min rate limits, tier-capped results, no bulk export.
- ✅ Billing wired + verified in **Stripe test mode**: Supabase `api_keys` store, free-key signup, Stripe Checkout upgrade, signed webhook flips the key to Pro — full pay→Pro loop tested.
- ⏳ You: deploy to your own account, set secrets, create the table, wire your Stripe price + webhook (one-time, see `CONNECT.md`).
- ⛔ Live revenue: still on Stripe **test** keys/price. Going live = a "weekend flip" to a live secret key + live price id + live-mode webhook secret. No live billing until then.
