# How the Data API Works (plain-English manual)

You have a dataset you maintain (a spreadsheet of funds). People can look at it for free
on your website. This kit lets **programs and AI agents** use that same data — but they
pay for it. Here's what happens under the hood, in order.

## 1. One door, two languages
The whole thing is a single cloud worker. It answers in two ways from the same data:
- **REST** — normal web requests (`/api/v1/...`), for any app or script.
- **MCP** — a special endpoint (`/mcp`) that AI agents understand natively, so an agent
  can discover the tools, sign up, and pull data on its own.

Both roads run the exact same query logic and the same paywall, so they can never drift
apart or be played against each other.

## 2. The paywall (the whole point)
When a program asks for data without a key, it gets a polite **"402 — payment required"**:
*humans browse free at the website; programmatic access needs a key.* This is the wall
that turns your data into a product. A human reading your site never sees it.

## 3. Getting a key
The program (or its agent) asks for a **free key** with just an email. It gets a key like
`rir_…` instantly. The free tier is real but limited: basic fields only, small result
caps, low daily quota — enough to try, not enough to rebuild your dataset.

## 4. Upgrading (where the money is)
To get all fields and high limits, the holder upgrades to **Pro**. The worker hands back a
Stripe checkout link. They pay; Stripe calls the worker back (a signed "webhook"); the
worker flips that key to Pro in the database. Cancel later and it flips back to free —
all automatic, no manual touching.

## 5. The tiers (what each gets)

| Tier | Price | Fields | Per query | Per day | Per minute |
|---|---|---|---|---|---|
| **Free** | $0 | basic (ticker, company, yield, payout, price) | 25 rows | 100 | 20 |
| **Pro** | $X/mo | all fields (+ AUM, distributions, inception, strategy, underlying, category) | 500 rows | 10,000 | 120 |
| **Enterprise** | contact | full-dataset export + resale rights — a separate commercial license | — | — | — |

## 6. The parts and what each does

| Part | What it does |
|---|---|
| **Tier resolver** | Looks up a key, decides free / pro / no-access. Caches for a minute so it's fast. |
| **Rate limiter** | Counts calls per key, per day and per minute; blocks with `429` when over quota. |
| **The dataset loader** | Fetches your published CSV, parses it, cleans junk rows, caches it for an hour. |
| **Query logic** | One shared function does single-fund lookup and filtered search; trims fields to the caller's tier and caps the row count. |
| **Stripe checkout** | Creates a subscription checkout session tied to the key. |
| **Stripe webhook** | Verifies Stripe's signature, then flips the key's tier on pay / change / cancel. |
| **Key store** | A Supabase table (`api_keys`) holding key, tier, status, email, and Stripe ids. |
| **MCP server** | Exposes `about`, `get_free_key`, `upgrade_to_pro`, `get_fund`, `search_funds` so an agent can do the whole flow itself. |

## 7. Why there's no "download everything" button
Every response is capped by tier, on purpose. A free user can't page through the whole
table, and even Pro is limited per query. The complete dataset is the **commercial
license** (Enterprise) — that's the asset, so it's never given away through the API.

## Two roads by who's asking
- **A human** → reads your website, free, never sees the API.
- **A program or agent** → hits the API, gets walled, gets a free key, upgrades to Pro
  when it needs more. The data is the same; the access is metered and paid.

## Why it won't get stuck or leak
- No key, no data — the `402` wall is the first thing checked on every data call.
- The Stripe webhook is **signature-verified**; a forged callback can't grant Pro.
- The webhook always answers "ok" even on an internal hiccup, so Stripe never retry-storms.
- Demo keys in config let you test all tiers before Supabase + Stripe are even connected,
  and the worker degrades gracefully (clear errors) if a piece isn't wired yet.
