# Connect & Deploy — RIR Data API (one-time setup)

Everything here is a one-time setup on **your own** Cloudflare + Supabase + Stripe +
dataset. No secret is baked into the kit; you supply your own.

## 1. Get the worker
The worker is a single `worker.js` (see `worker/README.md`). Drop it next to a
`wrangler.toml`, then deploy with Wrangler:
```
npx wrangler deploy
```
A free Cloudflare Workers plan is enough — no Queues or paid features required.

## 2. Point it at your dataset + site
Two constants at the top of `worker.js`:
- `MASTER_CSV` — a CSV URL for your dataset (e.g. a Google Sheet "publish to web → CSV"
  link, or any hosted CSV). It's fetched and cached for an hour.
- `SITE` — your public "get a key" / docs page URL (used in error messages + upgrade links).

The CSV parser maps common column names (Ticker, Company / Fund Name, Dividend, Current
Price, payout/frequency, AUM, Inception, Strategy, Underlying, Category) and drops issuer
header rows. Adjust the field map in `parseMasterCSV` if your columns differ.

## 3. Set the secrets
```
npx wrangler secret put SUPABASE_URL            # your Supabase project URL (the key store)
npx wrangler secret put SUPABASE_SERVICE_KEY    # Supabase service-role key (server-side only)
npx wrangler secret put STRIPE_SECRET_KEY       # Stripe secret key (test first, then live)
npx wrangler secret put STRIPE_WEBHOOK_SECRET   # Stripe webhook signing secret (whsec_...)
```
Non-secret vars go in `wrangler.toml` `[vars]` (see `config.example.json`):
- `STRIPE_PRICE_ID` — your recurring Pro price id.
- `API_KEYS` — optional JSON of demo keys, e.g. `{"free_demo":"free","pro_demo":"pro"}`, a
  zero-infra fallback so the tiers work before Supabase + Stripe are connected.

## 4. Create the Supabase key store
One table, server-side access only (RLS on; the worker uses the service-role key):
```sql
create table api_keys (
  key                    text primary key,
  tier                   text not null default 'free',   -- 'free' | 'pro'
  status                 text not null default 'active',
  email                  text,
  stripe_customer_id     text,
  stripe_subscription_id text,
  created_at             timestamptz not null default now(),
  updated_at             timestamptz
);
alter table api_keys enable row level security;   -- no anon policy: service-role only
```

## 5. Wire Stripe
1. Create a **recurring price** (e.g. $39/mo) → put its id in `STRIPE_PRICE_ID`.
2. Add a webhook endpoint pointing at `POST https://<your-worker>/api/billing/webhook`,
   subscribed to: `checkout.session.completed`, `customer.subscription.created`,
   `customer.subscription.updated`, `customer.subscription.deleted`.
3. Copy the webhook's signing secret into `STRIPE_WEBHOOK_SECRET`.

The pay→Pro flow is then automatic: `POST /api/billing/checkout {key}` returns a checkout
URL; on payment the signed webhook flips that key to Pro; cancel flips it back to free.

## 6. Test the loop
```
# create a free key
curl -X POST https://<worker>/api/keys -d '{"email":"you@example.com"}'
# use it (REST)
curl "https://<worker>/api/v1/funds?limit=5&key=rir_..."
# the 402 wall (no key)
curl "https://<worker>/api/v1/funds"
# MCP (agents): POST JSON-RPC to /mcp — call "about" first, then "get_free_key"
```

## Going live (the weekend flip)
The kit ships verified in **Stripe test mode**. To take real money:
1. Swap `STRIPE_SECRET_KEY` to your **live** secret key.
2. Set `STRIPE_PRICE_ID` to a **live-mode** price id.
3. Register a **live-mode** webhook and set its `STRIPE_WEBHOOK_SECRET`.
No code changes — just the three credentials.

## Downgrade / graceful behavior
- No `SUPABASE_URL` set → key store is skipped; only the `API_KEYS` demo keys resolve.
- No Stripe secrets → `/api/billing/*` returns `billing_unconfigured` (503) but data still serves to existing keys.
- Dataset CSV unreachable → `503 upstream` ("data temporarily unavailable"), never a crash.
- `GET /health` returns `{ ok: true }` for uptime checks.
