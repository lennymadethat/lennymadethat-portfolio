# The Worker

The whole API is a **single-file Cloudflare Worker** (`worker.js`) — REST + an MCP server
+ Stripe billing in one ES-module Worker. It's generic: the dataset and site are two
constants at the top; tiers, fields, secrets, and the price id come from config / vars /
Worker secrets. No person or brand is hardcoded into the logic.

## Source map (within `worker.js`)
- **`fetch` (router)** — CORS, `/mcp` (POST/DELETE), `/` + `/docs`, `/health`, account/billing routes, then the key-gated `/api/v1/*` data routes.
- **Account / billing** — `createKey(Core)` (free signup + per-IP anti-spam), `checkout(Core)` (Stripe Checkout session), `webhook` (signed Stripe callback → tier flip). The `*Core` halves are shared by both REST and MCP so there's one source of truth.
- **Key resolution** — `resolveTier` (demo-vars → 1-min cache → Supabase), `sb`/`getKeyRow`/`updateKey` (Supabase REST with the service-role key), `verifyStripeSig` (HMAC-SHA256, timing-safe compare).
- **Rate limiting** — `bump` (per-key per-day + per-minute counters in in-memory Maps).
- **Shared query logic** — `selectFund` (single ticker) + `queryFunds` (filter/sort/cap), `project` (trim fields to the tier). REST and MCP both call these.
- **Dataset** — `getMaster` (fetch + 1h cache), `parseMasterCSV` (column map + junk/issuer-row filter), `csvRow` + `cnum`/`cstr` helpers.
- **MCP server** — `mcpHandler` / `mcpDispatch` / `mcpCallTool` (JSON-RPC 2.0, stateless Streamable HTTP), `MCP_TOOLS` (`about`, `get_free_key`, `upgrade_to_pro`, `get_fund`, `search_funds`), `aboutPayload`, `docsPage`.

## Secrets vs vars
- **Secrets** (`wrangler secret put`): `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`.
- **Vars** (`wrangler.toml [vars]`): `STRIPE_PRICE_ID`, `API_KEYS` (optional demo keys).
- **Constants** (top of `worker.js`): `MASTER_CSV` (your dataset), `SITE` (your get-a-key page).

## Deploy
`npx wrangler deploy`. See `../CONNECT.md` for the Supabase table, Stripe price + webhook,
and the going-live (test → live) flip.

## Architecture in one line
one HTTP request → **resolve key** (free | pro | `402`) → **rate-limit** → **load+cache the
dataset CSV** → **shared query** (field-trim + row-cap by tier) → JSON; Stripe Checkout +
signed webhook move a key between free and pro. REST and MCP are two faces of the same
gated query logic. No bulk export.
