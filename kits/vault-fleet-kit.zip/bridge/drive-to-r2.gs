/**
 * Drive → Fleet bridge (Google Apps Script). Runs on Google's servers (PC off),
 * every 5 min: forwards new files from your Drive uploads folder to the Fleet,
 * moves the original to `_sent`, parks files >40MB in `_too-big`.
 *
 * SETUP (≈3 min): paste into https://script.google.com (New project), fill the
 * three CONFIG values, run `bridgeOnce` once (authorize), then run `installTrigger`.
 *   - UPLOADS_FOLDER_ID: open your uploads folder in Drive; the id is the last part
 *     of the URL (drive.google.com/drive/folders/THIS_PART).
 */
const CONFIG = {
  FLEET_URL: 'https://YOUR-FLEET.workers.dev',   // your deployed vault-fleet-worker URL
  FLEET_TOKEN: 'YOUR_FLEET_PASSWORD',            // matches the Worker's FLEET_TRIGGER_TOKEN secret
  UPLOADS_FOLDER_ID: 'PASTE_FOLDER_ID',          // your Drive uploads folder id
  SENT_SUBFOLDER: '_sent',
  TOOBIG_SUBFOLDER: '_too-big',
  MAX_MB: 40,
  MAX_PER_RUN: 12,
};

function bridgeOnce() {
  const folder = DriveApp.getFolderById(CONFIG.UPLOADS_FOLDER_ID);
  const sent = getOrCreateSub_(folder, CONFIG.SENT_SUBFOLDER);
  const tooBig = getOrCreateSub_(folder, CONFIG.TOOBIG_SUBFOLDER);
  const files = folder.getFiles();
  let n = 0, ok = 0, parked = 0;
  while (files.hasNext() && n < CONFIG.MAX_PER_RUN) {
    const file = files.next();
    n++;
    if (file.getSize() > CONFIG.MAX_MB * 1024 * 1024) {
      file.moveTo(tooBig); parked++;
      Logger.log('parked (too big): ' + file.getName());
      continue;
    }
    try {
      const blob = file.getBlob();
      const url = CONFIG.FLEET_URL + '/upload?process=false&name=' + encodeURIComponent(file.getName());
      const res = UrlFetchApp.fetch(url, {
        method: 'post',
        contentType: blob.getContentType() || 'application/octet-stream',
        payload: blob.getBytes(),
        headers: { 'x-fleet-token': CONFIG.FLEET_TOKEN },
        muteHttpExceptions: true,
      });
      if (res.getResponseCode() === 200) { file.moveTo(sent); ok++; }
      else { Logger.log('upload failed ' + file.getName() + ': ' + res.getResponseCode()); }
    } catch (e) { Logger.log('error on ' + file.getName() + ': ' + e); }
  }
  if (ok > 0) UrlFetchApp.fetch(CONFIG.FLEET_URL + '/run?limit=6', { method: 'post', headers: { 'x-fleet-token': CONFIG.FLEET_TOKEN }, muteHttpExceptions: true });
  Logger.log('bridge: sent ' + ok + ', parked ' + parked + ', of ' + n);
  return ok;
}

function getOrCreateSub_(folder, name) {
  const it = folder.getFoldersByName(name);
  return it.hasNext() ? it.next() : folder.createFolder(name);
}

function installTrigger() {
  ScriptApp.getProjectTriggers().forEach(t => { if (t.getHandlerFunction() === 'bridgeOnce') ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('bridgeOnce').timeBased().everyMinutes(5).create();
  Logger.log('trigger installed — bridgeOnce runs every 5 minutes.');
}
