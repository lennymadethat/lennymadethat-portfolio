# How the Vault Fleet Works (plain-English manual)

You drop things in one place. The system reads them and files them for you. That's it.
Here's what happens under the hood, in order.

## 1. The drop zone
One folder is the front door — your vault's `raw/uploads`. Drop anything there from any
device: a PDF, a photo, a voice memo, a video, a spreadsheet, a note. You never touch
any cloud dashboard or command line.

## 2. The bridge (your computer can be off)
A tiny Google script runs **on Google's servers**, checks the folder every 5 minutes,
and forwards each new file to the cloud worker. Files over 40 MB are set aside in a
`_too-big` folder for the big-file path. Because it runs on Google's side, none of this
needs your PC on.

## 3. The cloud inbox + queue
The file lands in cloud storage (Cloudflare R2). The moment it lands, it becomes one
durable **job** on a queue. A job that fails retries on its own and never blocks the
others — nothing is ever half-done or lost.

## 4. The sorter
The worker reads the file (PDFs and images are read by Claude; audio and video are
transcribed by Gemini), figures out **what it is** and **which project it belongs to**,
then files the original away and hands the rest off to the agents.

## 5. The agents (each its own job)
Each specialized agent runs independently:

| Agent | What it does |
|---|---|
| **Ingester** | Writes a clean summary page into your vault. |
| **Tagger** | Suggests links to related notes. |
| **Action-Items** | Pulls out to-dos and deadlines. |
| **Receipts** | Logs expenses from bills and invoices. |
| **People** | Notes who's mentioned — a mini contact list. |
| **Cross-Project** | Spots ideas that could help your other projects. |
| **Atomizer** | Turns content into reusable idea cards. |
| **Roll-up** | Adds what's new to the matching project page — never overwriting what you wrote. |

Every agent logs its own row to a **message board** so you can see exactly who did what.

## 6. The results
You end up with: a searchable summary page in your vault, fresh to-dos on the right
project, and a row on your dashboard — all without lifting a finger after the drop.

## Two roads by file size
- **Normal files** ride the bridge to the cloud and process in seconds.
- **Big files** (long videos) are parked and handled where they already live, so size is
  never a wall.

## Why it won't get stuck
Each file is its own job, and each agent is its own job. One failure retries alone and
blocks nothing. A file only leaves the inbox after it fully succeeds.
