# The Worker

The Fleet's brain is the **`vault-fleet-worker`** Cloudflare Worker (a multi-file
ES-module Worker). It's generic — every stack-specific value comes from `wrangler.toml`
`[vars]`, Worker secrets, or `config.json` (see `../config.example.json`). No person or
brand is hardcoded.

## Files (in the worker repo)
- `src/index.js` — router + cron + queue consumer (sorter dispatch + per-agent fan-out) + R2 instant-trigger handling.
- `src/lib.js` — model layer (Claude), extraction (text/pdf/image), classifier, helpers.
- `src/media.js` — audio/video → text via the Gemini File API (no ffmpeg).
- `src/workers.js` — the 8 agents.
- `src/rollup.js` — append-only project roll-up (project index from the vault Supabase).
- `src/vault-write.js` — inline vault write (chunk → embed → upsert pages/chunks).
- `src/events.js` — dashboard `ingest_events` + the `fleet_agent_runs` message board.
- `wrangler.toml` — bindings (R2 buckets, queues producer/consumer + DLQ, cron, vars).

## Deploy
`npx wrangler deploy`. See `../CONNECT.md` for buckets, queue, secrets, and the instant trigger.

## Architecture in one line
cron/upload/R2-event → **enqueue one job per file** → consumer **dispatches** (extract +
classify + stage + file original) → **fans out one isolated job per agent** → each agent
runs/retries/logs independently. Durable, instant, any-file-type, PC-off.
