# Connect & Deploy — Vault Fleet (one-time setup)

Everything here is a one-time setup on **your own** Cloudflare + Supabase + API keys.
No secret is baked into the kit; you supply your own.

## 1. Get the worker
The worker source is the `vault-fleet-worker` repo. Clone it, then `npm`-less deploy with
Wrangler (`npx wrangler deploy`). You need a Cloudflare account on the **Workers Paid**
plan (Queues require it).

## 2. Create the storage + queue
```
npx wrangler r2 bucket create vault-fleet-inbox
npx wrangler queues create vault-fleet-jobs
npx wrangler queues create vault-fleet-dlq
```
(Optional second source bucket, e.g. for scanned PDFs: `wrangler r2 bucket create vault-scans`.)

## 3. Set the secrets
```
npx wrangler secret put ANTHROPIC_API_KEY                 # classify + read PDFs/images
npx wrangler secret put OPENAI_API_KEY                    # vault embeddings
npx wrangler secret put GEMINI_API_KEY                    # audio/video transcription
npx wrangler secret put VAULT_SUPABASE_SERVICE_ROLE_KEY   # your vault Supabase (pages/chunks)
npx wrangler secret put LENNYOS_SUPABASE_SERVICE_ROLE_KEY # your ops Supabase (dashboard tables)
npx wrangler secret put FLEET_TRIGGER_TOKEN               # a password you choose — gates /upload + /run
```
Set the public URLs + bucket names in `wrangler.toml` `[vars]` (see `config.example.json`).

## 4. Create the Supabase tables
Your vault Supabase needs `pages` + `chunks` (pgvector) — the standard vault-mcp schema.
Your ops Supabase needs `ingest_events` and `fleet_agent_runs` (permissive-anon RLS).
SQL for `fleet_agent_runs` is in the worker repo's migrations note.

## 5. Turn on the instant trigger
```
npx wrangler r2 bucket notification create vault-fleet-inbox --event-type object-create --queue vault-fleet-jobs
```
Now a file landing in the bucket processes in seconds (the cron is the every-15-min safety net).

## 6. Install the Drive bridge
Paste `bridge/drive-to-r2.gs` into script.google.com → fill `FLEET_URL`, `FLEET_TOKEN`,
and your `UPLOADS_FOLDER_ID` → run `bridgeOnce` once (authorize) → run `installTrigger`
once. Drops in your folder now flow to the cloud automatically. Full click-by-click is in
the script's header comment.

## 7. (Optional) website upload button
Point a file input at `POST {FLEET_URL}/upload` with header `x-fleet-token: <your password>`.
Best for normal-size files (the worker buffers them); big files use the Drive folder.

## Big files (multi-GB, cloud, PC off)
The bridge parks files >40 MB in a `_too-big` folder. Two ways to process them:
- **Free / local:** point a local copy of the fleet's watcher at the `_too-big` folder (full
  ffmpeg, any size, runs when your PC is on).
- **Always-on cloud:** create a **Google service account**, enable the Drive API, share the
  `_too-big` folder with it, store the key as a Worker secret, and a cron job streams each big
  file from Drive into Gemini. ~15-min Google Cloud setup (only you can mint the credential).

## Downgrade behavior
No Workers Paid plan → no Queues; run the worker's `/run?inline=true` path (small batches) or
the local fleet instead. The kit degrades gracefully and tells you what's missing at `/health`.
