# Vault Fleet Kit

An always-on **agent fleet** that turns a dumping ground into a filed, summarized,
cross-referenced knowledge base — automatically, with your computer off. Drop any
file (PDF, photo, audio, video, CSV, note) into one folder; a cloud worker reads it,
figures out what it is, runs a fleet of specialized agents on it, and writes the
results into your vault.

Built 2026-06-18 for Lenny's vault. Ships as a **reusable kit** with a sanitization
boundary, so it drops onto anyone's stack (their own Cloudflare + Supabase + keys).

---

## The loop

```
  drop a file        Drive→cloud bridge        R2 inbox + queue        the Fleet           your vault
 (any device)  ──►   (Apps Script, PC off) ──► (one job per file) ──►  (sorter +     ──►   summary page +
                                                                        N agents)           project to-dos +
                                                                                            dashboard row
```

Every file becomes one durable **job**. A *sorter* extracts + classifies it, then fans
out **one isolated job per agent** — each runs, retries, and is logged on its own.

---

## What's in the box

```
vault-fleet-kit/
├─ README.md                ← you are here
├─ EXPLAINER.md             ← plain-English "how it works" manual (the instruction manual)
├─ CONNECT.md               ← one-time setup: deploy the worker, set secrets, install the bridge
├─ manifest.json            ← agent-readable surface (an agent parses this to understand/run/buy it)
├─ config.example.json      ← swap these values for your stack (the sanitization boundary)
├─ bridge/
│  └─ drive-to-r2.gs        ← Google Apps Script: watches your Drive folder, forwards to the Fleet
└─ worker/
   └─ README.md             ← the worker source lives in the vault-fleet-worker repo; how to deploy it
```

---

## Quickstart

1. **Deploy the worker** — clone `vault-fleet-worker`, `wrangler deploy`. See `CONNECT.md`.
2. **Set the secrets** — Anthropic, OpenAI, Gemini, your two Supabase service-role keys, a password. `CONNECT.md` lists them.
3. **Create the R2 bucket + queue** — one command each (`CONNECT.md`).
4. **Install the bridge** — paste `bridge/drive-to-r2.gs` into script.google.com, fill your folder id + password, run the two setup functions. Now dropping a file in your folder just works.
5. **(Optional) upload button** — point a web upload box at `POST /upload`.

---

## Reuse it for your own stack (sanitization boundary)

Everything specific lives in **two places** — swap them and the kit is yours:

1. `config.example.json` → `config.json`: bucket names, Supabase project URLs, the vault
   page conventions, the trigger password. **No secrets in this file** — every credential
   is a Worker secret set with `wrangler secret put`.
2. The **bridge config** at the top of `bridge/drive-to-r2.gs`: your Drive folder id, your
   Fleet URL, your password.

The worker code is already generic — it reads env + config, never hardcodes a person.

---

## Design tokens (for any HTML surface)

Kit HTML pages (explainers, dashboards) use the locked house tokens so everything looks
uniform: background `#0a1320`, gold `#f5b842`, mint `#6ee7c7`, surface `#0d1a2b` / card
`#11233a`; fonts Cinzel (display), Inter (body), JetBrains Mono (data). Reuse these — do
not invent new palettes per page.

---

## Status

- ✅ Worker live (`vault-fleet-worker`): R2 inbox, durable queue, instant R2 trigger, per-agent fan-out, media (audio/video via Gemini), message board.
- ✅ Drive→cloud bridge (Apps Script) + big-file local handler.
- ⏳ You: deploy to your own account, set secrets, install the bridge (one-time, see `CONNECT.md`).
- ⛔ Big files in the cloud (multi-GB from Drive): needs a Google service-account credential — see `CONNECT.md` "Big files."
