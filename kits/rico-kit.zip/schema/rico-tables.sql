-- ===========================================================================
-- RICO ENGINE — Supabase schema (the 6 rico_ tables + enums + storage bucket).
-- Run this in the Supabase SQL editor of YOUR project. RICO piggybacks one project;
-- everything is rico_-prefixed so it coexists with other tables.
--
-- RLS ships permissive-anon (fine for a PRIVATE instance behind access control).
-- Before any public/sellable variant: tighten writes to service-role-only and add a
-- trigger making raw_text immutable after insert. See CONNECT.md security note.
-- ===========================================================================

-- ---- ENUMS ----------------------------------------------------------------
-- Persona/agent values. Ships minimal: 'rico' + 'lenny-primary'. Add your own
-- agent value here if a second persona needs its own fingerprint agent.
do $$ begin create type rico_agent       as enum ('rico','lenny-primary');                                                  exception when duplicate_object then null; end $$;
do $$ begin create type rico_dump_source as enum ('text-dump','recording','photo','audio','transcript','paste');           exception when duplicate_object then null; end $$;
do $$ begin create type rico_card_type   as enum ('raw_idea','content_candidate','trade_thought','builder_note','methodology_source'); exception when duplicate_object then null; end $$;
do $$ begin create type rico_thread       as enum ('rir','lennymadethat-meta','us3-ops','coach-metagogans','ai-vs-ai');      exception when duplicate_object then null; end $$;
do $$ begin create type rico_topic        as enum ('trading','high-yield-income','market-news','youtube','hybrid');         exception when duplicate_object then null; end $$;
do $$ begin create type rico_audience     as enum ('free','paid','x','all');                                                exception when duplicate_object then null; end $$;
do $$ begin create type rico_urgency      as enum ('urgent','standard','evergreen');                                        exception when duplicate_object then null; end $$;
do $$ begin create type rico_card_status  as enum ('fresh','used','retired');                                               exception when duplicate_object then null; end $$;
-- authored_by: MILO/DON were killed by design — keep 'lennymadethat-meta' on rico_thread (a brand stream, not an agent).
do $$ begin create type rico_authored_by  as enum ('lenny','rico','rico+lenny-approved');                                   exception when duplicate_object then null; end $$;
do $$ begin create type rico_pub_format    as enum ('newsletter','x-post','x-thread','trade-desk-note','youtube-script','blog-article','lead-magnet'); exception when duplicate_object then null; end $$;
do $$ begin create type rico_pub_channel   as enum ('beehiiv','x','trade-desk','youtube','substack');                       exception when duplicate_object then null; end $$;
do $$ begin create type rico_pub_slot      as enum ('sunday','tuesday','x-daily','ad-hoc');                                  exception when duplicate_object then null; end $$;
do $$ begin create type rico_engine        as enum ('atomizer','transcription','tagger','drafter-sunday','drafter-x','voice-trainer','publish-recorder'); exception when duplicate_object then null; end $$;
do $$ begin create type rico_run_status     as enum ('running','success','failed','partial');                              exception when duplicate_object then null; end $$;
do $$ begin create type rico_run_trigger    as enum ('manual','scheduled','api','auto','phone-upload','approval');         exception when duplicate_object then null; end $$;

-- ---- rico_dumps : raw material as it lands. One row per dump event. ---------
create table if not exists rico_dumps (
  id                   uuid primary key default gen_random_uuid(),
  created_at           timestamptz not null default now(),
  source               rico_dump_source default 'paste',
  raw_text             text,                 -- SACRED — never edited after insert
  storage_path         text,                 -- for file uploads (audio etc.)
  storage_bucket       text,
  thread               rico_thread default 'rir',
  label                text,
  notes                text,
  processed_at         timestamptz,
  atomized_card_count  int default 0
);

-- ---- rico_cards : the library. One row per atomic idea. --------------------
create table if not exists rico_cards (
  id                uuid primary key default gen_random_uuid(),
  created_at        timestamptz not null default now(),
  source_dump_id    uuid references rico_dumps(id),
  card_type         rico_card_type default 'raw_idea',
  thread            rico_thread default 'rir',
  topic             rico_topic default 'hybrid',
  audience          rico_audience default 'all',
  format_candidates text[] default '{}',
  tickers           text[] default '{}',
  issuers           text[] default '{}',
  concepts          text[] default '{}',
  urgency           rico_urgency default 'standard',
  status            rico_card_status default 'fresh',
  raw_text          text not null,            -- verbatim, SACRED
  gloss             text,                     -- one-sentence summary
  why_it_matters    text,                     -- 2-3 sentence editorial
  lenny_correction  text,                     -- owner edits here, not raw_text
  used_in           uuid[] default '{}',      -- -> rico_publications
  related_cards     uuid[] default '{}',      -- -> rico_cards
  agent_subject     text[] default '{}',      -- phase 2+: content about other agents
  authored_by       rico_authored_by default 'lenny'
);

-- ---- rico_publications : what actually shipped. One row per published piece. -
create table if not exists rico_publications (
  id            uuid primary key default gen_random_uuid(),
  created_at    timestamptz not null default now(),
  published_at  timestamptz,
  format        rico_pub_format default 'x-post',
  channel       rico_pub_channel default 'x',
  title         text,
  url           text,
  body_text     text,
  cards_used    uuid[] default '{}',          -- -> rico_cards
  authored_by   rico_authored_by default 'rico+lenny-approved',
  slot          rico_pub_slot default 'ad-hoc',
  -- metrics jsonb holds draft_state (pending_approval / checks_failed / approved_send_stubbed
  -- / sent / drafted_in_beehiiv / rejected), the voice+disclaimer checks, central_analogy,
  -- image_state/image_url, beehiiv_draft, etc. The approval state machine lives here.
  metrics       jsonb default '{}'::jsonb
);

-- ---- rico_voice_fingerprints : versioned voice synthesis. ------------------
create table if not exists rico_voice_fingerprints (
  id                  uuid primary key default gen_random_uuid(),
  created_at          timestamptz not null default now(),
  agent               rico_agent default 'rico',
  version             int not null,
  markdown            text not null,          -- the fingerprint document
  source_publications uuid[] default '{}',    -- -> rico_publications used to train
  approved_by_lenny   boolean default false,  -- GUARDRAIL: engines use approved only
  approved_at         timestamptz
);

-- ---- rico_engine_runs : run history per engine. ---------------------------
create table if not exists rico_engine_runs (
  id                uuid primary key default gen_random_uuid(),
  started_at        timestamptz not null default now(),
  finished_at       timestamptz,
  engine            rico_engine,
  status            rico_run_status default 'running',
  inputs_processed  int default 0,
  outputs_produced  int default 0,
  error_message     text,
  triggered_by      rico_run_trigger default 'manual'
);

-- ---- rico_agents_subjects : phase-2 stub ("a DCC for agents"). ------------
create table if not exists rico_agents_subjects (
  id              uuid primary key default gen_random_uuid(),
  name            text not null,
  category        text,
  operator        text,
  notes           text,
  first_covered_at timestamptz default now(),
  coverage_count  int default 0
);

-- ---- STORAGE : private bucket for uploaded audio + generated header images. -
insert into storage.buckets (id, name, public)
values ('rico-raw','rico-raw', false)
on conflict (id) do nothing;

-- ---- RLS : permissive-anon for a PRIVATE instance. Tighten before public. --
alter table rico_dumps               enable row level security;
alter table rico_cards               enable row level security;
alter table rico_publications        enable row level security;
alter table rico_voice_fingerprints  enable row level security;
alter table rico_engine_runs         enable row level security;
alter table rico_agents_subjects     enable row level security;

do $$
declare t text;
begin
  foreach t in array array['rico_dumps','rico_cards','rico_publications','rico_voice_fingerprints','rico_engine_runs','rico_agents_subjects']
  loop
    execute format('drop policy if exists %I_anon_all on %I;', t, t);
    -- PERMISSIVE-ANON: read+write for anon. PRIVATE-instance only. For a public/sellable
    -- variant, replace with service-role-only writes + read policies scoped per your needs.
    execute format('create policy %I_anon_all on %I for all to anon using (true) with check (true);', t, t);
  end loop;
end $$;
