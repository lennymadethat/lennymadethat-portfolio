// ===========================================================================
// PERSONA LAYER (sanitized example) — config, not code branches.
//
// Copy this into the worker's src/personas.js and edit the one entry to make RICO
// YOUR operative. The agent is a BRAND wrapped around a team of dumb workers (the
// engines). A persona is { id, display_name, fingerprint_agent, character, wedge }.
// Draft endpoints accept a `persona_id`; the engine loads the matching config and
// injects it (plus that persona's APPROVED voice fingerprint markdown, looked up by
// fingerprint_agent) into the model call.
//
// Persona #1 is your operative. Add a second entry to run a SECOND operative on the
// same Worker — no endpoint changes, no per-agent enum names, no per-persona code path.
// Everything persona-specific lives in this map.
// ===========================================================================

export const PERSONAS = {
  rico: {
    id: 'rico',
    display_name: 'YOUR-OPERATIVE-NAME',
    // Which rico_voice_fingerprints.agent row backs this persona's voice.
    // The rico_agent enum ships as ('rico','lenny-primary'). Keep 'rico' unless you
    // add your own agent value to the enum in schema/rico-tables.sql.
    fingerprint_agent: 'rico',
    character:
      'ONE-OR-TWO SENTENCES describing the operative as a character — who it is, who ' +
      'it writes for, and the tone (e.g. "irreverent but technically credible; ' +
      'practitioner, not advisor").',
    // The wedge — the editorial point of view EVERY draft must respect. This is the
    // single most load-bearing brand value: be specific and opinionated.
    wedge:
      'ONE PARAGRAPH stating your editorial point of view: who you write for, what you ' +
      'believe that others do not, the non-negotiable stances, and the voice. RICO ' +
      'enforces this on every draft and the voice/disclaimer checks lean on it.',
  },

  // ----- Add a second operative here as persona #2 on this same Worker. -----
  // second: {
  //   id: 'second',
  //   display_name: 'Second Operative',
  //   fingerprint_agent: 'lenny-primary', // or a new agent value added to the enum
  //   character: '...character + tone...',
  //   wedge: '...the second brand\'s editorial wedge...',
  // },
};

export const DEFAULT_PERSONA = 'rico';

export function getPersona(personaId) {
  return PERSONAS[personaId || DEFAULT_PERSONA] || PERSONAS[DEFAULT_PERSONA];
}
