# RICO Kit — the Content Operative

A named **content operative** for a newsletter/social brand. You ramble (type, paste,
or talk into your phone); RICO **atomizes** the raw material into a searchable library
of idea **cards**, **drafts** content in your voice (X posts, replies, threads, full
newsletters), **checks itself** against your voice + a mandatory disclaimer, and drops
a finished newsletter into Beehiiv as a draft. **RICO drafts and remembers — he never
posts autonomously. You approve everything before anything ships.**

RICO is the *Retail Investor Report* instance of a generic product called **The Content
Operative**. The persona is a single config entry (`personas.js`) — point it at a
different voice/brand and the same Worker becomes a different operative.

Built across **Build 05** (engine + X drafting loop), **Build 06** (phone → newsletter),
**Build 06.5** (Beehiiv draft loop via the write MCP), and **Build 06.6** (Voice Studio).
Ships as a **reusable kit** with a sanitization boundary, so it drops onto anyone's stack
(their own Cloudflare + Supabase + keys + Beehiiv).

---

## The loop

```
  you ramble          /atomize                cards                  drafters                  approval + ship
 (type / paste / ──►  (raw -> idea       ──►  (verbatim raw_text,──►  /draft (X, 3 angles)  ──► you approve  ──► X post
  phone voice)         cards, in voice)       sacred; tagged)         /draft-newsletter         (phone +        Beehiiv draft
                                                                      (voice + disclaimer       desktop)        (you click Publish)
                                                                       self-checks)
```

Every dump becomes verbatim **cards** (the library). Drafters assemble cards into content,
**gate it on a voice-check + a disclaimer-check**, then hold it for your explicit approval.
The one send path (`/publish`) is hard-gated: explicit token + a chosen audience + passed
checks — and even then, the *Beehiiv Publish click stays manual by design*.

---

## What's in the box

```
rico-kit/
├─ README.md                ← you are here
├─ EXPLAINER.md             ← plain-English "how it works" manual (the instruction manual)
├─ CONNECT.md               ← one-time setup: deploy the worker, create infra, set secrets
├─ manifest.json            ← agent-readable surface (an agent parses this to understand/run/buy it)
├─ config.example.json      ← swap these values for your stack/brand (the sanitization boundary)
├─ schema/
│  └─ rico-tables.sql       ← the 6 rico_ tables + enums + storage bucket (your Supabase)
├─ worker/
│  └─ README.md             ← the worker source lives in the rico-engine repo; files + how to deploy it
└─ persona/
   └─ persona.example.js    ← the persona config (sanitized) — point RICO at your own voice/brand
```

The **newsletter-only feature** (push a finished draft into Beehiiv via the write MCP) is
packaged separately as `Documents/newsletter-to-beehiiv-kit` — RICO embeds that capability
(`/newsletter-export` + `/mark-drafted`). This kit is the **full operative**; that one is the
single newsletter capability if that's all you want.

---

## Quickstart

1. **Deploy the worker** — clone `rico-engine`, `npx wrangler deploy`. See `CONNECT.md`.
2. **Create the Supabase tables + bucket** — run `schema/rico-tables.sql` against your
   Supabase project (6 `rico_` tables + enums + a private `rico-raw` bucket). `CONNECT.md`.
3. **Set the secrets** — `ANTHROPIC_API_KEY` (required) + a `RICO_APPROVAL_TOKEN`; optional
   `OPENAI_API_KEY` (Whisper + header image), `BEEHIIV_*` (REST send), `SUPABASE_SERVICE_ROLE_KEY`.
   `CONNECT.md` lists each with a one-line why.
4. **Set your brand/voice** — copy `persona/persona.example.js` into the worker's
   `src/personas.js` and point it at your wedge; set `[vars]` in `wrangler.toml`.
5. **Seed + approve a voice** — open `/voice` (the Voice Studio): seed your published work
   as corpus, **Retrain**, then **Approve** v1 (engines won't use an unapproved voice).
6. **Use it** — phone page at `/m` (record or type a ramble); `/how` explains it to a human;
   `/manifest` + `/status` + `/publications` are the read-only agent door.

---

## Reuse it for your own stack/brand (sanitization boundary)

Everything specific lives in **two places** — swap them and the kit is yours:

1. `config.example.json` → `config.json` and the worker's `wrangler.toml` `[vars]`:
   Supabase project URL, allowed browser origins, the draft model, the locked house
   image style, the Beehiiv segment ids. **No secrets in these** — every credential is a
   Worker secret set with `wrangler secret put`.
2. The **persona** at `src/personas.js` (`persona/persona.example.js` here): the
   `display_name`, `character`, and `wedge` are the entire brand voice seam. RICO = persona
   #1; add a second entry and the same Worker runs a second operative — no endpoint changes.

The worker code is already generic — it reads `env` + persona config, never hardcodes a
person. `PUBLIC_BUILD=true` marks the downloadable variant's sanitization boundary in-code.

---

## Design tokens (for any HTML surface)

Kit HTML pages (the `/m` phone page, `/voice` Voice Studio, `/how` explainer) use the locked
house tokens so everything looks uniform: background `#0a1320`, gold `#f5b842`, mint
`#6ee7c7`, surface `#0d1a2b` / card `#11233a`, body-text `#b9c6d6`; fonts Cinzel (display),
Inter (body), JetBrains Mono (data). Section header = mint bold; primary buttons = gold bg
`#0a1320` text. Reuse these — do not invent new palettes per page.

---

## Status

- ✅ Worker live (`rico-engine`): atomizer, persona-aware X drafter (3 angles), voice
  trainer + scorer + interview (Voice Studio at `/voice`), phone surface (`/m`),
  newsletter drafter with voice + disclaimer gate, header-image generator, the guarded
  `/publish`, and the Beehiiv-MCP draft loop (`/newsletter-export` + `/mark-drafted`).
- ✅ Live loop proven end-to-end: ramble → `/draft-newsletter` → `/newsletter-export` →
  Beehiiv write MCP → `/mark-drafted` (a real draft was created). Voice fingerprint v1
  APPROVED + active.
- ⏳ You: deploy to your own account, run the SQL, set secrets, set your persona, seed +
  approve a voice (one-time, see `CONNECT.md`).
- ⛔ **Direct REST `/publish` send is Enterprise-Beehiiv-only.** On Scale tier the real path
  is the MCP draft loop + a manual Publish click (by design). `/publish` logs + best-effort
  posts but the send stays manual without the Enterprise tier.
- ⚠️ Default RLS is permissive-anon (fine for a private instance behind access control;
  tighten writes to service-role-only before any public/sellable variant).
