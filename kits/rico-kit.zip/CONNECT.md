# Connect & Deploy — RICO (one-time setup)

Everything here is a one-time setup on **your own** Cloudflare + Supabase + API keys +
Beehiiv. No secret is baked into the kit; you supply your own.

## 1. Get the worker
The worker source is the `rico-engine` repo (a multi-file ES-module Cloudflare Worker:
`src/index.js` router + engines, `src/lib.js` model/Supabase layer, `src/prompts.js`
prompt templates, `src/personas.js` persona config). Clone it, then deploy with Wrangler:

```
npx wrangler login        # supplies the account; no account_id is hardcoded
npx wrangler deploy
```

A Cloudflare Workers account on the free plan is enough — RICO uses no Queues or Durable
Objects. (`/health` reports what's wired.)

## 2. Create the Supabase tables + storage bucket
RICO piggybacks one Supabase project. Run the kit's SQL against it:

```
# In the Supabase SQL editor, paste and run:
schema/rico-tables.sql
```

This creates the **6 `rico_` tables** (`rico_dumps`, `rico_cards`, `rico_publications`,
`rico_voice_fingerprints`, `rico_engine_runs`, `rico_agents_subjects` stub), the **enums**
they use, and a **private `rico-raw` storage bucket** (for uploaded audio + generated header
images). RLS is enabled permissive-anon by default — see the security note at the bottom.

Set `SUPABASE_URL` + `SUPABASE_ANON_KEY` (the publishable anon key, governed by RLS) in
`wrangler.toml` `[vars]`. The anon key is safe to ship; it is NOT a secret.

## 3. Set the secrets
```
npx wrangler secret put ANTHROPIC_API_KEY          # REQUIRED — atomize/draft/voice/newsletter. Absent = those return 503.
npx wrangler secret put RICO_APPROVAL_TOKEN        # a long random string you choose — the owner guard for /publish, /reject, /approve-voice, /mark-drafted
npx wrangler secret put SUPABASE_SERVICE_ROLE_KEY  # OPTIONAL — engine writes bypass RLS when set; absent = anon-key fallback
npx wrangler secret put OPENAI_API_KEY             # OPTIONAL — Whisper transcription + house-style header image. Absent = both report pending_key, never block.
npx wrangler secret put BEEHIIV_API_KEY            # OPTIONAL — REST send (Enterprise tier only). Absent = /publish logs + stubs the send.
npx wrangler secret put BEEHIIV_PUBLICATION_ID     # OPTIONAL — target publication for REST send.
npx wrangler secret put BEEHIIV_SEGMENT_FREE       # OPTIONAL — audience id for free sends.
npx wrangler secret put BEEHIIV_SEGMENT_PAID       # OPTIONAL — audience id for paid sends.
```
Set the public `[vars]` (allowed origins, draft model, version, house image style) in
`wrangler.toml` — see `config.example.json` for every value.

## 4. Set your brand / voice (the persona)
Copy `persona/persona.example.js` into the worker's `src/personas.js` and edit the one
entry: `display_name`, `character`, and `wedge` (the editorial point of view every draft
must respect). That map IS the brand seam — point it at your own voice and RICO is yours.
Add a second entry to run a second operative on the same Worker (no endpoint changes).

## 5. Seed + approve a voice (engines won't use an unapproved voice)
Open `https://<your-worker>.workers.dev/voice` (the Voice Studio):
- Seed corpus: paste your published work as `methodology_source` cards, **or** record a few
  publications, **or** use **Train by interview** (RICO asks, you ramble).
- Hit **Retrain** → a new **unapproved** fingerprint is synthesized.
- Review it, then hit **Approve**. RICO now drafts in that voice. (Until a voice is approved,
  drafts run against the wedge and are flagged voice-unverified.)

## 6. Use it
- **Phone:** add `https://<your-worker>.workers.dev/m` to your home screen — record or type
  a ramble; approve drafts there.
- **Voice Studio:** `/voice` — train, approve, score drafts.
- **Human explainer:** `/how`.
- **Agent door (read-only):** `/manifest` (full route list with shapes), `/status` (engine
  runs + pipeline counts), `/publications` (published-content view). Foreign agents read
  these, never the tables.

## 7. Newsletter → Beehiiv (the draft loop)
Beehiiv's REST **create-post is Enterprise-only**, so on the **Scale tier** the Worker can't
push a fresh newsletter via `/publish`. The real path is the **Beehiiv write MCP**:
1. `POST /draft-newsletter` (from `/m` or a Claude session) → a `pending_approval` draft.
2. `GET /newsletter-export` → a Beehiiv-ready payload (`title`, `subtitle`, `body_markdown`,
   `body_html`, `thumbnail_url`, `checks`).
3. A Claude surface holding the **Beehiiv write MCP** creates the Beehiiv draft from that payload.
4. `POST /mark-drafted` (owner-token) → records the Beehiiv post id + URL; dashboard shows
   "in Beehiiv, awaiting Publish."
5. You open Beehiiv and click **Publish** (manual by design at any tier).

The standalone newsletter capability is packaged at `Documents/newsletter-to-beehiiv-kit`
(skill + portable prompt + the same two Worker endpoints) if you only want that loop.

## Downgrade behavior (graceful)
- No `ANTHROPIC_API_KEY` → atomize/draft/voice/newsletter return a clear 503 with a hint, never crash.
- No `OPENAI_API_KEY` → transcription + header image report `pending_key`; the draft still forms.
- No `BEEHIIV_*` → `/publish` logs the publication and stubs the send; use the MCP draft loop.
- No `SUPABASE_SERVICE_ROLE_KEY` → the Worker uses the anon key against permissive RLS.
- No Beehiiv Enterprise tier → the REST `/publish` send stays manual; the MCP draft loop is the path.

## Security note (read before any public/sellable variant)
Default RLS is **permissive-anon**: raw dumps/drafts/fingerprints are readable + writable with
the inlined anon key, and the Approve gate is **app-layer only** (a raw anon UPDATE could flip
`approved_by_lenny`). That's acceptable for a **private instance behind access control** (e.g.
Cloudflare Access). Before exposing RICO publicly: tighten writes to **service-role-only**, add
a DB trigger making `raw_text` immutable after insert, and set `PUBLIC_BUILD=true` so the
owner-only routes refuse a non-empty-but-unverified token.
