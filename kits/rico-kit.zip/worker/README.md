# The Worker

RICO's brain is the **`rico-engine`** Cloudflare Worker (a multi-file ES-module Worker).
It's generic — every stack/brand-specific value comes from `wrangler.toml` `[vars]`, Worker
secrets, or `src/personas.js` (see `../config.example.json` and `../persona/persona.example.js`).
No person or brand is hardcoded; `PUBLIC_BUILD=true` marks the downloadable variant's
sanitization boundary in-code.

## Files (in the rico-engine repo)
- `src/index.js` — the router + all engines: agent door (`/manifest` `/status` `/publications`),
  HTML surfaces (`/m` phone, `/voice` Voice Studio, `/how` explainer), `/atomize`, `/draft`,
  voice (`/retrain-voice` `/approve-voice` `/voice-status` `/voice-score` `/voice-interview`),
  phone→newsletter (`/record-upload` `/record-text` `/transcribe` `/draft-newsletter`
  `/generate-header`), the guarded send (`/pending` `/publish` `/reject`), and the Beehiiv-MCP
  draft loop (`/newsletter-export` `/mark-drafted`). Includes the `ownerGuard` + the commented
  `walletGuard` x402 stub (architected seam, builds nothing live).
- `src/lib.js` — model layer (Claude), Supabase REST helpers (select/insert/update/storage/
  signed-url, service-role-vs-anon), engine-run logging, Whisper, image gen, Beehiiv REST,
  markdown→HTML.
- `src/prompts.js` — prompt templates: atomizer, draft-system builder, voice synth, newsletter
  template, header-image prompt, the voice scorer + interview prompts, and `runContentChecks`
  (the voice + disclaimer gate).
- `src/personas.js` — the persona map (config, not code branches). RICO = #1; add an entry to
  run a second operative. **This is the brand seam.**
- `wrangler.toml` — `[vars]` (allowed origins, draft model, version, house image style,
  Supabase URL + anon key, `PUBLIC_BUILD`) + the commented secret list.

## Supabase
Run `../schema/rico-tables.sql` against your project: 6 `rico_` tables + enums + the private
`rico-raw` bucket. The Worker prefers `SUPABASE_SERVICE_ROLE_KEY` (secret) and falls back to
the publishable anon key against permissive RLS.

## Deploy
`npx wrangler deploy` (account from `npx wrangler login`; no `account_id` is hardcoded, so the
template deploys to any account unchanged). See `../CONNECT.md` for tables, secrets, persona,
and the seed-and-approve-a-voice step.

## Architecture in one line
ramble (type/voice) → `/atomize` into verbatim cards → persona-aware drafters (`/draft` X
3-angles, `/draft-newsletter` voice+disclaimer-gated) → approval queue → guarded `/publish`
**or** the Beehiiv-MCP draft loop → you click Publish. Drafts and remembers; never posts
autonomously.
