# How RICO Works (plain-English manual)

You hand RICO raw material — a typed note, a pasted transcript, or a voice ramble from
your phone. He turns it into content in your voice, checks his own work, and hands it back
for your approval. Nothing ever goes out without your tap. Here's what happens under the
hood, in order.

## 1. The dump (the front door)
Everything starts as a **dump** — one raw thing you handed over. Three ways in:

- **Type or paste** a ramble into the phone page's text box (or any surface).
- **Record** a voice note on the phone page — RICO transcribes it for you.
- **Hand him cards** you already made earlier from the library.

A dump is stored **exactly as you said it**. RICO never rewrites your raw words.

## 2. Atomizing into cards
RICO reads a dump and breaks it into **cards** — one atomic idea each. Each card keeps your
verbatim words (sacred, never edited), plus a one-line summary, a "why it matters" note, and
tags (topic, audience, tickers, urgency, what format it could become). The cards are your
searchable **library**. Content gets built *from* the library, never invented from nothing.

## 3. The voice
RICO writes in **your** voice, not a generic AI voice. He learns it from a **voice
fingerprint** — a document synthesized from your published work and from a short
interview where he asks and you ramble. You **approve** a fingerprint before he's allowed
to use it; he can never silently change the voice you're shipping in. The **Voice Studio**
page is where you see why it sounds like you, retrain it, and **score any draft 0–100**
against it ("sounds exactly like you" vs "sounds nothing like you").

## 4. The drafters
Two kinds of output, each its own engine:

| Drafter | What it does |
|---|---|
| **X drafter** | Turns a card or a seed into **3 distinct angles** for a post, reply, or thread. |
| **Newsletter drafter** | Turns a ramble (or chosen cards) into a full newsletter draft. |

## 5. The two self-checks (the gate)
Before any newsletter can reach you for approval, RICO runs **two checks on himself**:

1. **Voice check** — does it sound like you?
2. **Disclaimer check** — is the mandatory "educational only, not advice" line present, and
   is every yield anchored to a real dollar amount over a time window (no bare percentages)?

A draft that fails either check is marked `checks_failed` and **cannot be approved** until
it's fixed. This is the guardrail, built first.

## 6. The header picture
While a newsletter draft is forming, RICO kicks off a **header image** in the locked house
style (a humorous vintage-newspaper illustration of the draft's central analogy). If no
image key is set, it just says "pending" — it never blocks the draft.

## 7. Your approval
The finished draft shows up on the **phone page** and the dashboard with its checks visible.
You can **Send free**, **Send paid**, or **Reject**. Sending requires your **approval token**
and an explicitly chosen audience — RICO will never pick the audience for you.

## 8. Into Beehiiv (the honest limit)
Here's the one thing RICO **cannot** do: click Publish in Beehiiv. Beehiiv's send-by-API is
locked to their top Enterprise plan. So on a normal plan, the loop is: RICO writes and
**creates the Beehiiv draft** (through the Beehiiv write tool, from a Claude session), records
it, and the dashboard shows "in Beehiiv, awaiting your Publish click." You open Beehiiv and
click Publish. That's the deliberate human hand on the trigger — and where you pick the audience.

## 9. What gets remembered
When something actually ships, it's logged as a **publication**, and the cards it used are
flipped to "used" so they aren't reused by accident. Every engine run (atomize, draft,
transcribe, voice-train, publish) is logged so you can see exactly who did what, when, and
whether it failed.

---

## The parts, at a glance

| Part | Plain-English job |
|---|---|
| **Dump** | The raw thing you handed over (verbatim, never edited). |
| **Atomizer** | Cuts a dump into atomic idea cards. |
| **Cards / library** | Your searchable idea bank — content is built from this. |
| **Voice fingerprint** | The document that makes RICO sound like you (you approve it). |
| **Voice Studio** | See / retrain / approve the voice; score any draft against it. |
| **X drafter** | 3 angles for a post / reply / thread. |
| **Newsletter drafter** | A full newsletter from a ramble, voice + disclaimer gated. |
| **Header image** | House-style picture for the newsletter (never blocks). |
| **Approval queue** | The drafts waiting for your tap (phone + desktop). |
| **Publish gate** | The guarded "go" — token + chosen audience + passed checks. |
| **Beehiiv draft loop** | Drops the finished piece into Beehiiv; you click Publish. |
| **Publications log** | What actually shipped; used cards flip to "used". |

## Two roads (by where you start)
- **Phone:** open the home-screen page, tap to record or type a ramble, approve later.
- **Laptop / Claude app:** say "draft a newsletter about …" and it drafts + pushes the
  Beehiiv draft for you, then you approve.

## Why it won't get stuck or break
- **Nothing autonomous.** No post, no send, no voice change ever happens without your explicit
  token-gated tap. The send path was built rejection-first.
- **Your words are sacred.** Raw text is stored verbatim and never edited by any engine.
- **Idle by default.** Feeds only fill from material you actually handed over — RICO never
  invents content from nothing.
- **Missing keys degrade gracefully.** No Anthropic key → drafting reports a clear 503, never
  a crash. No image key → "pending", never a block. No Beehiiv → the draft is still logged.
