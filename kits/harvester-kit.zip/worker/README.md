# The Worker

The Harvester's brain is the **`harvester-worker`** Cloudflare Worker (a multi-file
ES-module Worker). It's generic — every stack-specific value comes from `wrangler.toml`
`[vars]`, Worker secrets, or `config.json` (see `../config.example.json`). No person or
brand is hardcoded; the `wrangler.toml` holds **no secrets and no account IDs**
(`wrangler login` supplies the account).

## Files (in the worker repo)
- `src/index.js` — router: `GET /` + `GET /health` (public), `GET /status` + `POST /harvest`
  (token-gated), CORS, the single-isolate run lock, and input validation (rejects
  non-YouTube URLs and unknown lenses before any credits are spent).
- `src/lib.js` — CORS + JSON helpers, the token gate (`x-harvester-token`), YouTube id parse.
- `src/lenses.js` — the 6 lens frames + their methodology-file paths (read live from the
  vault per run, so editing a methodology file tunes the lens with no redeploy). **This is
  where you rename lenses to your own domains.**
- `src/gemini.js` — native YouTube ingest: the URL is passed as a `file_data` video part
  (request shape verified against ai.google.dev), with model fallback on length/quota error.
- `src/synthesize.js` — Claude lens synthesis → locked JSON
  (`{ title, channel, duration, tl_dr, lens_synthesis, action_items[], raw_points[] }`).
  The Raw lens skips this step.
- `src/vault-write.js` — the vault page write: a 1:1 port of the vault-mcp write
  (chunk → embed with `text-embedding-3-large` → upsert `pages`/`chunks`), plus
  `listPagesByPrefix` / `readManyPages` helpers used to load methodology context.
- `src/harvest.js` — the per-URL pipeline: ingest → synthesize → write page → append
  action items to project pages → log a `harvest_events` row. Holds the sealed-zone (US3)
  handling.
- `src/preflight.mjs` — no-write diagnostic: presence+length key checks, a live Gemini
  call, a live Anthropic call, and Supabase reads. `npm run preflight`.
- `wrangler.toml` — `[vars]` (allowed origins, the two Supabase URLs, model strings,
  methodology char cap) + observability. No secrets, no account IDs.

## Deploy
`npm install && npx wrangler deploy`. See `../CONNECT.md` for secrets, the Supabase
schema, the lens methodology files, preflight, and wiring a trigger.

## Architecture in one line
authenticated `POST /harvest` → **Gemini watches the YouTube URL natively** → **Claude
synthesizes through the chosen lens** (loading your methodology files live) → **write a
harvested page through the online vault + append routed action items** → **log a
`harvest_events` row**. Synchronous per request, single-operator, PC-off. The **Raw** lens
skips synthesis; the **US3** lens is a sealed zone (synthesis stays inside the boundary,
the log row carries non-sensitive metadata only).
