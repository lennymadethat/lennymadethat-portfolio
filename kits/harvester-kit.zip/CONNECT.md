# Connect & Deploy — Harvester (one-time setup)

Everything here is a one-time setup on **your own** Cloudflare + Supabase + API keys.
No secret is baked into the kit; you supply your own.

## 1. Get the worker
The worker source is the `harvester-worker` repo. Clone it, install deps, deploy with
Wrangler:

```sh
npm install
npx wrangler login        # one-time
npx wrangler deploy
```

A free Cloudflare Workers account is enough — the Harvester uses no Queues or R2 (it runs
synchronously per request), so no paid plan is required.

## 2. Point `wrangler.toml` `[vars]` at your stack
Open `wrangler.toml` and set the **non-secret** values (these are committed config, not
secrets — see `config.example.json` for the full list):

```
ALLOWED_ORIGINS        = "https://your-dashboard.example.com,http://localhost:8788"
VAULT_SUPABASE_URL     = "https://YOUR-VAULT-PROJECT.supabase.co"
LENNYOS_SUPABASE_URL   = "https://YOUR-OPS-PROJECT.supabase.co"
GEMINI_MODEL           = "gemini-2.5-pro"
GEMINI_FALLBACK_MODEL  = "gemini-2.5-flash"
ANTHROPIC_MODEL        = "claude-sonnet-4-6"
METHODOLOGY_CHAR_CAP   = "80000"
```

## 3. Set the secrets
```sh
npx wrangler secret put GEMINI_API_KEY                  # native YouTube ingestion (aistudio.google.com, free tier)
npx wrangler secret put ANTHROPIC_API_KEY               # lens synthesis (claude-sonnet-4-6)
npx wrangler secret put OPENAI_API_KEY                  # embeddings for the vault page write (text-embedding-3-large)
npx wrangler secret put HARVESTER_TRIGGER_TOKEN         # a password you choose — gates POST /harvest + /status
npx wrangler secret put VAULT_SUPABASE_SERVICE_ROLE_KEY # your vault Supabase (read methodology, upsert pages/chunks)
npx wrangler secret put LENNYOS_SUPABASE_ANON_KEY       # your ops Supabase (insert/read harvest_events)
```

Generate the trigger token with:
```sh
node -e "console.log(require('crypto').randomBytes(24).toString('base64url'))"
```
Use the **same value** wherever your trigger button stores its token.

## 4. Create the Supabase pieces
- **Ops project:** a `harvest_events` table (permissive-anon RLS: anon read/insert/update +
  service_role insert). Columns: `source_url, title, channel, duration, lens,
  routed_projects, vault_page, summary, reasoning, status` (`harvested` / `needs_review` /
  `error`), `error`.
- **Vault project:** the standard **vault-mcp schema** — `pages` + `chunks` (pgvector).
  The harvested-page write is a 1:1 port of the vault-mcp write (chunk → embed with
  `text-embedding-3-large` → upsert). It also **reads** your methodology files from `pages`
  at harvest time, so your lens rules must live in that vault as pages (e.g.
  `wiki/methodology/rir-rules.md`).

> **Self-host caveat:** this vault-write/read coupling is the one part that isn't generic.
> The harvest runs end-to-end without it (Gemini extraction + Claude synthesis + the
> `harvest_events` log row), but the "writes into your vault" and "loads your methodology"
> steps assume vault-mcp-style `pages`/`chunks` tables plus a sync worker that mirrors rows
> back to local Markdown. If you don't run that stack, treat the worker as an
> extract-and-synthesize service and adapt `src/vault-write.js` to your own store.

## 5. Provide your lens methodology files
Each lens loads one or more files from your vault, **read live on every harvest** (edit a
file → the lens re-tunes, no redeploy). The reference mapping (override in `src/lenses.js`):

| Lens | Loads |
|---|---|
| RIR (℞) | `wiki/methodology/rir-rules.md` + `wiki/methodology/content-rules/*` |
| Personal (ψ) | `wiki/identity.md` + `wiki/identity-physical.md` |
| US3 (Ω) | `wiki/methodology/us3-rules.md` (sealed zone) |
| Fitness (Δ) | `wiki/methodology/fitness-rules.md` + `wiki/identity-physical.md` |
| LMT (⚒) | `wiki/methodology/trailer-rules.md` + `wiki/projects/lennymadethat-brand.md` |
| Raw (∅) | nothing — no synthesis |

Rename these to your own domains and point the paths at your real files. The **Raw** lens
works with no files at all, so you have a no-config starting point.

## 6. Preflight (no-write sanity check)
```sh
cp .env.example .env     # fill in the keys; .env is gitignored
npm run preflight
```
Checks every key (presence + length only — never values), does a live Gemini call, a live
Anthropic call, and Supabase reads against `harvest_events` + `pages`. Prints all-green or
names the failure.

## 7. Wire a trigger
The worker is UI-agnostic. Any surface that can send an authenticated POST works:

```sh
curl -X POST https://harvester-worker.YOUR-SUBDOMAIN.workers.dev/harvest \
  -H "x-harvester-token: YOUR_TRIGGER_TOKEN" \
  -H "content-type: application/json" \
  -d '{"urls":["https://youtube.com/watch?v=..."],"lens":"RIR","focus":"optional"}'
```

The reference build calls it from a Lenny OS dashboard panel (lens selector, URL field,
Focus field, an Extract button, a `/health` engine dot, and an activity feed reading
`harvest_events`). The token is stored in the browser's `localStorage` only — never
committed. Build whatever front end you like; the contract is just the POST above.

## Graceful downgrade
- **No vault-mcp schema?** The worker still extracts + synthesizes + logs; only the vault
  page write/methodology read need adapting (step 4).
- **No methodology files?** Lenses fall back to their built-in frame; the **Raw** lens
  needs nothing.
- **Video too long / quota hit?** Gemini auto-falls back from `2.5-pro` to `2.5-flash`.
- The `/health` endpoint reports `{ ok, version, vault, lenses }` so a panel can show a
  live engine dot and degrade its UI instead of presenting a dead button.

## Known credential gap
`HARVESTER_TRIGGER_TOKEN` is the only shared secret between the worker and the trigger UI.
Rotate it if it's ever printed/logged in plaintext (regenerate, `wrangler secret put` the
new value, update the UI's stored token). Worst case of a leak is someone who also knows
your Worker URL triggering harvests on your credits — low stakes, but rotate regardless.
