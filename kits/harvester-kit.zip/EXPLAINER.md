# How the Harvester Works (plain-English manual)

You paste a YouTube link, pick the "lens" you want it read through, and the system
watches the video and writes you back the useful parts — already shaped to your work.
That's it. Here's what happens under the hood, in order.

## 1. The drop
You give it two things: one or more **YouTube URLs** and a **lens**. A lens is just
*"read this for me as if you were thinking about ___"* — your business, your training,
your personal systems. You can also add a one-off **Focus** note ("only pull the pricing
stuff"). You never touch a command line.

## 2. Watching the video (Gemini)
The link goes straight to Google's Gemini, which can **watch a YouTube video directly** —
no downloading, no transcribing step. It comes back with a faithful, structured pull of
everything in the video: the talking points, key ideas, practices, names and tools,
numbers, stories, and claims, plus the title, channel, and length.

## 3. The lens (Claude)
Now the interesting part. The raw pull from Gemini goes to Claude **together with your own
rules file** for that lens. The lens isn't a label — it's a real document you wrote (your
methodology) that gets loaded in fresh every time. Claude reads the video *through* those
rules and writes back:

- a 3-sentence **TL;DR**,
- a **synthesis** — what this video means for that part of your world,
- a list of **action items**, each tagged and routed to the right project.

The **Raw** lens skips this entirely — you just get clean talking points, no spin, no API
spend on the synthesis step.

## 4. The lenses

| Lens | Glyph | Reads it as… |
|---|---|---|
| **RIR** | ℞ | …input for your newsletter / platform / business |
| **Personal** | ψ | …lifestyle, discipline, systems, habits |
| **US3** | Ω | …operations, leadership, workflow (a sealed zone — see below) |
| **Fitness** | Δ | …training: hypertrophy, skills, recovery |
| **LMT** | ⚒ | …builds, fabrication, brand/content ideas |
| **Raw** | ∅ | …nothing — just the clean talking points |

Because each lens loads a live file from your vault, **editing that file re-tunes the lens
instantly** — no code change, no redeploy.

## 5. The results
You end up with a clean **page in your vault** (date, source, title, the TL;DR, the
synthesis, the action items, and the raw points), the **action items appended onto the
matching project page** as real checkboxes so they show up in your to-do view, and a
**row on a dashboard log** so you can see every harvest that ran — including the ones that
failed or need a look.

## The sealed zone
The **US3** lens is private. Anything read through it (or any action item that routes to a
US3 project) keeps its full synthesis **inside the US3 boundary** — written under that
project's own folder. The public-ish dashboard log only ever sees non-sensitive metadata
(the URL, title, lens, which project, status). Sensitive synthesis never leaks into the
shared feed.

## Two roads by cost
- **Full lens harvest** spends a little Gemini + Claude (+ a tiny embedding) credit per
  video — this is the one-click automated path.
- **The $0 path** is the manual version: paste the URL into a Gemini chat with a harvest
  prompt, copy the block it gives you, paste it into a Claude chat and say "ingest this."
  Same idea, done by hand, no per-run spend. Use the worker when one-click is worth it.

## Why it won't get stuck
Bad input is caught early — non-YouTube links and unknown lenses are rejected before any
credits are spent. Gemini falls back to a lighter model if a video is too long or hits a
quota. If a harvest fails, it's **logged as a failure row** rather than silently lost, and
only one harvest runs at a time (a second request gets a polite "busy" instead of
colliding). The Raw lens always works even with no methodology files in place.
