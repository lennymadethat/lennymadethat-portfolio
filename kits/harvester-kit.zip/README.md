# Harvester Kit

Turn a **YouTube URL into filed inspiration**. Drop a video link, pick a **lens**
(the frame you want it read through), and a cloud worker watches the video, applies
your own playbook to it, and writes a structured page into your vault — with action
items routed onto the right project. PC off.

Built 2026-06-19 for Lenny's vault. Ships as a **reusable kit** with a sanitization
boundary, so it drops onto anyone's stack (their own Cloudflare + Supabase + keys).
Sibling to the Vault Ingestor: where the Ingestor files **your own** dumps, the
Harvester pulls **external** content.

---

## The loop

```
  paste YouTube URL        Gemini ingest             Claude lens synthesis        your vault
  + pick a lens      ──►   (native YouTube,     ──►  (loads your methodology  ──►  harvested page +
 (dashboard button)        no download)              file for that lens)          project to-dos +
                                                                                  dashboard row
```

Each video becomes a faithful Gemini extraction, then Claude reads it **through the
lens** — your own rules file for that domain — and produces a TL;DR, a synthesis, and
tagged action items. The **Raw** lens skips synthesis and just hands back clean talking
points.

---

## What's in the box

```
harvester-kit/
├─ README.md                ← you are here
├─ EXPLAINER.md             ← plain-English "how it works" manual (the instruction manual)
├─ CONNECT.md               ← one-time setup: deploy the worker, set secrets, wire the panel
├─ manifest.json            ← agent-readable surface (an agent parses this to understand/run/buy it)
├─ config.example.json      ← swap these values for your stack (the sanitization boundary)
└─ worker/
   └─ README.md             ← the worker source lives in the harvester-worker repo; how to deploy it
```

---

## Quickstart

1. **Deploy the worker** — get `harvester-worker`, `wrangler deploy`. See `CONNECT.md`.
2. **Set the secrets** — Gemini, Anthropic, OpenAI, your vault Supabase service-role key,
   your ops Supabase anon key, and a trigger token. `CONNECT.md` lists each.
3. **Point `wrangler.toml` `[vars]` at your stack** — your two Supabase URLs, allowed
   browser origins, model strings (see `config.example.json`).
4. **Wire the trigger** — any button (or `curl`) that `POST`s a URL + lens with your token
   header. The reference uses a Lenny OS dashboard panel; the worker is UI-agnostic.
5. **Run one short video** to calibrate, then tune the lens frames in `src/lenses.js` and
   your methodology files — that's where output quality lives or dies.

---

## Reuse it for your own stack (sanitization boundary)

Everything specific lives in **two places** — swap them and the kit is yours:

1. `config.example.json` → `config.json` (mirrored into `wrangler.toml [vars]`): your two
   Supabase project URLs, allowed origins, model strings, and the lens → methodology-file
   map. **No secrets in this file** — every credential is a Worker secret set with
   `wrangler secret put`.
2. **Your methodology files** in the vault (`wiki/methodology/*.md`, `wiki/identity*.md`,
   etc.). The lenses are only as good as the rules files they load — these are *your*
   playbook, read live on every harvest, so editing one tunes its lens with no redeploy.

The worker code is already generic — it reads env + config, never hardcodes a person.

---

## Design tokens (for any HTML surface)

Kit HTML pages (explainers, panels) use the locked house tokens so everything looks
uniform: background `#0a1320`, gold `#f5b842`, mint `#6ee7c7`, surface `#0d1a2b` / card
`#11233a`, body-text `#b9c6d6`; fonts Cinzel (display), Inter (body), JetBrains Mono
(data). Section headers = mint bold; primary buttons = gold background, `#0a1320` text.
Reuse these — do not invent new palettes per page.

---

## Status

- ✅ Worker built + deployed (`harvester-worker`): `POST /harvest` (token-gated),
  `GET /health` (public), `GET /status` (token-gated); native YouTube ingest via Gemini;
  Claude lens synthesis; vault write through the online vault; action-item routing to
  project pages; `harvest_events` accountability log. 7 lenses (RIR / Personal / US3 /
  Fitness / LMT / Visuals / Raw). Live as of 2026-06-17 (`/health` green, auth gate proven).
- ✅ Sealed-zone handling (US3): synthesis stays inside the boundary; the log row carries
  non-sensitive metadata only.
- ⏳ You: deploy to your own account, set secrets, point `[vars]` at your Supabase,
  write/port your methodology files, wire a trigger button (one-time, see `CONNECT.md`).
- ⚠️ **Self-host caveat — vault write coupling.** The vault page write is a 1:1 port of
  the vault-mcp write path (chunk → embed → upsert into `pages`/`chunks` with pgvector).
  It assumes a **vault-mcp-style Supabase schema** and a sync worker that mirrors those
  rows back to local Markdown. Without that schema the harvest still runs (Gemini + Claude
  + the log row), but the "writes into your vault" step needs the same `pages`/`chunks`
  tables. This is the one part that isn't drop-in for an arbitrary stack — see `CONNECT.md`.
- ⏳ Calibration: the lens frames + methodology files are tuned against real videos after
  the first runs. Out of the box they're sensible defaults, not finished prompts.
