# The Worker

Forge Runner is the **`forge-runner`** Cloudflare Worker (a multi-file ES-module Worker,
no SDK). It's generic — every stack-specific value comes from `wrangler.toml` `[vars]`,
Worker secrets, or `config.json` (see `../config.example.json`). No person, brand, or
account id is hardcoded; `wrangler login` supplies the account.

## Files (in the worker repo)
- `src/index.js` — the router: `POST /forge/run`, `GET /forge/runs/:id`, `GET /forge/health`, `OPTIONS *` (CORS). Last-resort fault guard; the interpreter isolates node failures itself.
- `src/interpreter.js` — **the engine**. Validate graph → Kahn topological sort (cycle-tolerant) → walk in order, gathering live-edge inputs → run each node's handler → collect terminal outputs → persist a `runs` record. Also `runWorkflowById` (loads `{graph}` from Supabase) and sub-workflow recursion (depth-limited 3).
- `src/handlers.js` — **the handler registry**, keyed by `node.type`. Uniform interface `async (node, inputs, env, ctx) => { output, status, error?, activePorts? }`. Holds the LLM callers (Claude/Gemini/Grok/GPT), connectors (Beehiiv draft, Supabase, HTTP, vault), the safe (no-`eval`) condition evaluator, branching logic, output routing, and the named agents (RICO/MILO/DON).
- `src/catalog.js` — the **contract mirror**: each node type's out-ports (must agree with The Forge composer's CATALOG). Adding a node type = add its ports here + a handler in `handlers.js`. The interpreter never changes.
- `src/vault-write.js` — inline vault read/write: chunk → OpenAI `text-embedding-3-large` → upsert `pages`/`chunks` into the vault Supabase (same pattern as harvester-worker / vault-ingestor, no external bridge).
- `src/supabase.js` — minimal Supabase REST helpers (select/insert/update, anon key, no SDK — keeps the Worker light + portable).
- `src/lib.js` — shared utilities: CORS, JSON responses, input→text coercion, `{{input}}` prompt interpolation, previews.
- `wrangler.toml` — `name`, `main`, compatibility date, `[vars]` (ALLOWED_ORIGINS, RUNNER_VERSION, VAULT_SUPABASE_URL). No secrets, no `account_id`.

## Deploy
`npm install` → `wrangler login` → `npm run deploy`. See `../CONNECT.md` for secrets, the
Supabase tables, and optional vault wiring. Local dev: `cp .dev.vars.example .dev.vars`,
fill keys, `npm run dev`.

## Architecture in one line
`POST /forge/run` → **validate + topologically order the blueprint** → **walk nodes**,
gathering each node's live upstream inputs and running its handler → **isolate failures**
(a node error stops only its branch) → **collect terminal outputs** + **persist a run
record**. The blueprint is data; the runner is fixed code. One engine, infinite blueprints.

## Adding a node type
1. Add its out-ports to `src/catalog.js` (`NODE_OUT_PORTS`).
2. Add a handler in `src/handlers.js` under the same `node.type` key.
3. Mirror its ports in The Forge composer's CATALOG so the two agree.
The interpreter needs no changes.
