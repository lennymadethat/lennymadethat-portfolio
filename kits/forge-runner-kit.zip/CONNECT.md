# Connect & Deploy — Forge Runner (one-time setup)

Everything here is a one-time setup on **your own** Cloudflare + Supabase + API keys.
No secret is baked into the kit; you supply your own. The Worker reads everything from
`env` (Worker secrets + `wrangler.toml` `[vars]`), so the template deploys to any account
unchanged.

## 1. Get the worker
The worker source is the `forge-runner` repo. Clone it, then deploy with Wrangler.
`wrangler login` supplies the Cloudflare account — there is no `account_id` in the
committed config.

```
npm install
wrangler login
npm run deploy        # = wrangler deploy
```

Local dev: `cp .dev.vars.example .dev.vars`, fill your keys, then `npm run dev`.

## 2. Set the secrets
Set each with `wrangler secret put NAME` (never commit them).

```
# --- Required: by-id runs + run persistence ---
wrangler secret put SUPABASE_URL          # your ops Supabase project URL
wrangler secret put SUPABASE_ANON_KEY     # its anon key (anon-RLS, matches the dashboard model)

# --- Required for any LLM / agent node ---
wrangler secret put ANTHROPIC_API_KEY     # enables engine.claude + agent.rico/milo/don/generic

# --- Optional providers (absence = that node reports "not configured", never crashes) ---
wrangler secret put GEMINI_API_KEY        # engine.gemini
wrangler secret put XAI_API_KEY           # engine.grok
wrangler secret put OPENAI_API_KEY        # engine.gpt AND vault-write embeddings

# --- Optional connectors ---
wrangler secret put BEEHIIV_API_KEY               # data.beehiiv / output.newsletter (drafts)
wrangler secret put BEEHIIV_PUBLICATION_ID
wrangler secret put VAULT_SUPABASE_SERVICE_ROLE_KEY  # data.vault_read/write + output.file
wrangler secret put GDRIVE_TOKEN                  # data.gdrive (interface wired, body pending)
```

Non-secret config goes in `wrangler.toml` `[vars]` (see `config.example.json`):
`ALLOWED_ORIGINS`, `RUNNER_VERSION`, and `VAULT_SUPABASE_URL` (public URL only — its
service-role key is the secret above).

## 3. Create the Supabase tables
On your ops Supabase project (the one `SUPABASE_URL` / `SUPABASE_ANON_KEY` point at),
with permissive-anon RLS to match the single-user dashboard model:

- **`runs`** — the run record sink. Columns used: `id` (uuid/text, PK), `workflow_id`
  (text, nullable), `status` (text), `started_at`, `finished_at` (timestamptz/text),
  `log` (jsonb), `output` (jsonb).
- **`workflows`** *(optional — only for `{ workflowId }` runs)* — `id` (PK), `name` (text),
  `graph` (jsonb = the exported blueprint). Without this table, inline `{ graph }` runs
  still work; by-id runs return a clear "supabase not configured / not found".
- **`dashboard_cards`** *(optional — output sink for `output.card` / `output.notify` /
  `logic.approval`)* — `deck`, `title`, `body`, `run_id`, `source`. Without it, cards
  still succeed but report `persisted:false`.

## 4. Vault read/write (optional, for `data.vault_*` + `output.file`)
These write pages **inline** — chunk → OpenAI `text-embedding-3-large` → upsert into a
`pages` / `chunks` (pgvector) schema on your **vault** Supabase. No external bridge.

- Set `VAULT_SUPABASE_URL` in `wrangler.toml` `[vars]` (or `.dev.vars` locally).
- Set `VAULT_SUPABASE_SERVICE_ROLE_KEY` as a secret. `data.vault_read` needs only those two.
- `data.vault_write` / `output.file` also need `OPENAI_API_KEY` (for embeddings).
- Missing any of these → the node **skips** and captures the artifact in the run output, so
  nothing is lost (never a crash).

## 5. Open it up (optional — public runner)
Set `ALLOWED_ORIGINS = "*"` in `wrangler.toml` `[vars]` to let any browser origin call the
API. Otherwise list your exact origins (comma-separated). CORS preflight is handled at
`OPTIONS *`.

## 6. Run something
```
curl -s -X POST https://forge-runner.<your-account>.workers.dev/forge/run \
  -H 'Content-Type: application/json' \
  -d '{"graph":{"workflow":{"name":"demo"},
       "nodes":[
         {"id":"n1","type":"trigger.manual","title":"Run","config":{},"position":{"x":0,"y":0}},
         {"id":"n2","type":"engine.claude","title":"Ask","config":{"prompt":"reply with exactly: FORGE OK"},"position":{"x":1,"y":0}}],
       "edges":[{"id":"e1","from":"n1","fromPort":"out","to":"n2","toPort":"in"}]}}'
```
Then `GET /forge/runs/:id` for the stored record, or `GET /forge/health` for a liveness ping.

## Downgrade behavior
- No `ANTHROPIC_API_KEY` → LLM/agent nodes `skip` (clear reason); the rest of the graph runs.
- No vault secrets → vault nodes `skip` and keep the artifact in the run output.
- No `dashboard_cards` table → cards still return `ok`, just `persisted:false`.
- No `workflows` table → inline `{ graph }` runs still work; only `{ workflowId }` is unavailable.

## Known credential / feature gaps (honest)
- **Media nodes** (`image.*`, `video.*`, `audio.whisper`): the handler interface is wired,
  but the real provider request bodies are **pending** — they return `skipped` with
  "provider body pending", never fake an image/video.
- **`data.gdrive`**: token wired, provider body pending.
- **Phase 4 (not yet built):** `logic.loop` per-item fan-out (v1 passes the array),
  `logic.delay` real delay (v1 logs a no-op), `logic.approval` resume (v1 halts + emits a
  card), and `agent.skill` execution (v1 logs the reference).
