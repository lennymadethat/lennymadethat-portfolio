# How Forge Runner Works (plain-English manual)

You draw a workflow as a diagram of connected boxes, save it, and this engine runs it.
That's it. The diagram is the *recipe*; this engine is the *cook* — one cook who can make
any recipe. Here's what happens under the hood, in order.

## 1. The blueprint
The Forge (the visual builder) exports your workflow as one JSON file: a list of **nodes**
(the boxes — "ask Claude", "fetch a URL", "write to my vault") and **edges** (the wires
between them). You either send that JSON straight to the runner, or save it in a table and
send just its id.

## 2. One engine for everything
There is **no code generated per workflow**. The same fixed engine reads any blueprint and
walks it. That is the whole trick: it means you can download one tool and run infinite
recipes, and it means the JSON is the only thing you ever need to share with someone else.

## 3. Putting the boxes in order
Before running, the engine sorts the boxes so every box runs *after* the boxes that feed
it (a "topological" order). If you accidentally draw a loop (A feeds B feeds A), it doesn't
hang — it processes what it can and flags the loop in the log.

## 4. Running each box
It walks the boxes in order. For each one it (a) gathers the outputs of the boxes wired
into it, (b) runs that box's **handler**, (c) stores the result, and (d) lights up the
box's output wires so the next boxes can read it.

| Box family | What it does |
|---|---|
| **Triggers** (`trigger.*`) | The starting box — manual, schedule, webhook, inbox, on-publish. Emits the first payload. |
| **Engines** (`engine.*`) | Send a prompt to an LLM: Claude, Gemini, Grok, GPT. The reply flows on. |
| **Agents** (`agent.*`) | Named operatives (RICO, MILO, DON) = Claude with a fixed persona; or a generic agent that can call another saved workflow as a sub-step. |
| **Data / IO** (`data.*`) | Read/write your vault, query Supabase, fetch a URL, push a Beehiiv draft, stage an X post (draft only). |
| **Logic** (`logic.*`) | Branch (`condition`), combine inputs (`merge`), loop, delay, and a human approval gate. |
| **Outputs** (`output.*`) | The terminal boxes: write a file to the vault, a newsletter draft, an X-post draft, a notification, or a dashboard card. |
| **Media** (`image.*` / `video.*` / `audio.*`) | Interface is wired; the actual provider calls are still being filled in (they say so honestly — see below). |

## 5. Branching and merging
- A **condition** box looks at its input and lights up *either* its `true` wire *or* its
  `false` wire — so only one path downstream runs.
- A box whose only feeders came down a path that didn't run is marked **skipped** (not
  failed) — it just had nothing to do.
- A **merge** box waits for several wires and joins them back into one.
- An **approval** box stops its branch and drops a "needs approval" card on your dashboard.

## 6. The results
Every run produces a **run record** saved to your database: an ordered list of every box,
its status (`ok` / `skipped` / `error`), a preview of what it produced, and any notes.
The *terminal* boxes' outputs are collected as the run's outputs. You read it back at
`GET /forge/runs/:id`.

## Two roads: configured vs not
- **A box whose provider key is set** runs for real.
- **A box whose key is missing** returns `skipped` with a plain reason
  ("no key configured for anthropic") — it never crashes the run and never fakes a result.
  So a half-configured stack still runs the parts it can.

## Why it won't get stuck or break
- **Failure isolation:** if one box throws, the engine catches it, logs it as `error`, and
  the rest of the run keeps going. One bad box never takes down the run.
- **Honest, never faked:** unconfigured providers and not-yet-built features say exactly
  that. Nothing pretends to have worked.
- **Safe for shared blueprints:** the `condition` box evaluates rules with a tiny safe
  parser — **no `eval`, no `new Function`** — so running a stranger's blueprint can't run
  arbitrary code.
- **Drafts, never auto-posts:** anything that touches X or a newsletter creates a *draft*
  for you to approve. The runner never publishes on its own.
- **Loop guard:** a workflow that calls other workflows is depth-limited (3) so it can't
  recurse forever.
