# Forge Runner Kit

The execution engine for **The Forge** — a visual workflow builder. The Forge lets
you *draw* a workflow and *save* it as a JSON blueprint; **Forge Runner reads that
blueprint and runs it**. One generic interpreter Worker runs *every* workflow — the
blueprint is data, the runner is fixed code that topologically walks any graph. No
per-workflow scripts are ever generated.

Built 2026-06-19 for Lenny's Forge. Ships as a **reusable kit** with a sanitization
boundary, so it drops onto anyone's stack (their own Cloudflare + Supabase + keys).
Bring your own keys; configure only the providers you actually have.

---

## The loop

```
  draw + save a          POST /forge/run            interpreter                 outputs
  workflow (The Forge) ──►  { graph } or       ──►  (topo-walk the graph,  ──►  vault page / Beehiiv
  → JSON blueprint          { workflowId }          run each node's handler,     draft / dashboard card /
                                                    isolate failures)            X draft / HTTP fetch
                                                          │
                                                          ▼
                                                   Supabase `runs`
                                                  (per-node log + outputs)
```

Every run becomes one durable **run record**: an ordered, per-node log
(`{ nodeId, type, status, outputPreview, error, notes }`) plus the terminal outputs.
A node that errors or is unconfigured is logged and its branch stops — the rest of
the run continues. A run never crashes silently.

---

## What's in the box

```
forge-runner-kit/
├─ README.md                ← you are here
├─ EXPLAINER.md             ← plain-English "how it works" manual (the instruction manual)
├─ CONNECT.md               ← one-time setup: deploy the worker, set secrets, wire the table
├─ manifest.json            ← agent-readable surface (an agent parses this to understand/run/buy it)
├─ config.example.json      ← swap these values for your stack (the sanitization boundary)
├─ .gitignore               ← ignores config.json, .dev.vars, keys
└─ worker/
   └─ README.md             ← the worker source lives in the forge-runner repo; files + how to deploy
```

---

## Quickstart

1. **Deploy the worker** — clone `forge-runner`, `wrangler login`, `npm run deploy`. See `CONNECT.md`.
2. **Set the secrets** — at minimum `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `ANTHROPIC_API_KEY`. Optional provider keys enable more node types. `CONNECT.md` lists each.
3. **Create the Supabase tables** — `runs` (run records) and optionally `workflows` (for by-id runs) + `dashboard_cards` (output sink). `CONNECT.md` has the shape.
4. **Run a blueprint** — `POST /forge/run` with `{ "graph": {…} }` (inline) or `{ "workflowId": "<uuid>" }` (loaded from Supabase). Check `GET /forge/runs/:id` for the record.

---

## Reuse it for your own stack (sanitization boundary)

Everything specific lives in **two places** — swap them and the kit is yours:

1. `config.example.json` → `config.json`: your Supabase project URLs, the vault page
   conventions, the allowed CORS origins, default models. **No secrets in this file** —
   every credential is a Worker secret set with `wrangler secret put`.
2. The `[vars]` block in `wrangler.toml`: `ALLOWED_ORIGINS`, `RUNNER_VERSION`,
   `VAULT_SUPABASE_URL` (public URL only; its service-role key is a secret).

The worker code is already generic — it reads `env` + the blueprint, never hardcodes a
person or account. `wrangler login` supplies the account, so the template deploys to any
Cloudflare account unchanged (no `account_id` in the committed config).

---

## Design tokens (for any HTML surface)

Kit HTML pages (explainers, dashboards) use the locked house tokens so everything looks
uniform: background `#0a1320`, gold `#f5b842`, mint `#6ee7c7`, surface `#0d1a2b` / card
`#11233a`, body-text `#b9c6d6`; fonts Cinzel (display), Inter (body), JetBrains Mono
(data). Section headers = mint bold; primary buttons = gold bg, `#0a1320` text. Reuse
these — do not invent new palettes per page.

---

## Status

- ✅ Worker live (`forge-runner`): generic interpreter, topo-walk, node-level failure isolation, run persistence, CORS. Deployed + Claude execution proven (2026-06-17).
- ✅ Vault read/write LIVE (Option B): `data.vault_read` / `data.vault_write` / `output.file` write pages inline (chunk → OpenAI embed → upsert `pages`/`chunks`), no external bridge. Proven end-to-end.
- ✅ Wired + honest: every LLM engine + Beehiiv draft + Supabase + HTTP + logic + agents. `data.x` / `output.x_post` are **draft-only — never auto-post**.
- ⏳ You: deploy to your own account, set secrets, create the tables (one-time, see `CONNECT.md`).
- ⛔ Media nodes (`image.*` / `video.*` / `audio.whisper`): interface wired but provider bodies pending — they report "not configured / pending", never fake output.
- ⛔ Connectors `data.gdrive` (token wired, body pending); `logic.loop` per-item fan-out, `logic.delay` real delay, `logic.approval` resume, and `agent.skill` execution are all Phase 4.
